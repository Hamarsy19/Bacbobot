from kivy.app import App
from kivy.uix.label import Label

class BotBacboApp(App):
    def build(self):
        return Label(text="Bot Bacbo funcionando!")

if __name__ == '__main__':
    BotBacboApp().run()
